<?php

/**
 * Created by PhpStorm.
 * User: peyagodson
 * Date: 7/15/2017
 * Time: 6:04 PM
 */

return [
    'host' => "localhost",
    'user' => 'root',
    'pwd' => "",
    'dbname' => 'slide'
];